#include "EngineTest.h"

Image *			image = NULL;			//pngͼƬ
HWND hWnd;
PAINTSTRUCT ps;
Graphics* graphics;
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	LPCTSTR winTitle = L"T_Engine���Գ���";
	EngineTest*test = new EngineTest(hInstance, WIN_CLASS, winTitle, NULL, NULL, 800, 600, WIN_BKCLR);
	T_Engine::pEngine = test;
	test->SetFrame(5);  //������Ϸ����֡ˢ��Ƶ��(ÿ��5֡)
	test->StartEngine();
	return TRUE;
}

EngineTest::EngineTest(HINSTANCE hInstance, LPCTSTR szWindowClass, LPCTSTR szTitle,WORD Icon, WORD SmIcon,int iWidth, 
	int iHeight,COLORREF bkColor):T_Engine(hInstance,szWindowClass,szTitle,Icon,SmIcon,iWidth,iHeight,bkColor){
	wnd_height = iHeight;
	wnd_width = iWidth;
}


EngineTest::~EngineTest(){}

/*
  ���ظ�������ĺ���ʵ�ֵ��ǿ�ʵ��;
*/
// ��Ϸ��ʼ��
void EngineTest::GameInit() {}
// ��Ϸ�߼�����
void EngineTest::GameLogic() {}
// ��Ϸ��������
void EngineTest::GameEnd() {}
// ����GAME_STATEֵ��ʾ��Ϸ����
void EngineTest::GamePaint(HDC hdc) {
	HGDIOBJ mbrush, oldbrush;
	HGDIOBJ mpen, oldpen;
	RECT mrect;
	int cell_width = wnd_width / 20;
	int cell_height = wnd_height / 20;
	for (int r = 0; r<20; r++) {
		for (int c = 0; c<20; c++) {
			
			mpen = CreatePen(PS_SOLID, 0, RGB(240, 240, 240));
			oldpen = SelectObject(hdc, mpen);
			mbrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
			oldbrush = SelectObject(hdc, mbrush);
			mrect.left = c*cell_width;
			mrect.right = mrect.left + cell_width;
			mrect.top = r*cell_height;
			mrect.bottom = mrect.top + cell_height;
			//FillRect(hdc, mrect.left, mrect.top, mrect.right, mrect.bottom);
			FillRect(hdc, &mrect, (HBRUSH)mbrush);
			Rectangle(hdc, mrect.left, mrect.top, mrect.right, mrect.bottom);
			SelectObject(hdc, oldbrush);
			DeleteObject(mbrush);
			SelectObject(hdc, oldpen);
			DeleteObject(mpen);
		}
	}

}
void OnBnClickedBtnShowBmp(HWND hWnd)
{

	static TCHAR        szFileName[MAX_PATH];


	HWND hwnd;
	HDC hdc;


	hwnd = hWnd;

	hdc = ::GetDC(hwnd);

	BITMAP              bitmap;

	HDC                 hdcMem;

	BITMAPFILEHEADER bmfh;
	BITMAPINFO     * pbmi;
	BYTE           * pBits;
	BOOL             bSuccess;
	DWORD            dwInfoSize, dwBytesRead;
	HANDLE           hFile;
	HBITMAP          hBitmap;

	memcpy(szFileName, _T(".\\qr_code.bmp"), 50);
	hFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ,
		NULL, OPEN_EXISTING, 0, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
		return;

	// Read in the BITMAPFILEHEADER

	bSuccess = ReadFile(hFile, &bmfh, sizeof(BITMAPFILEHEADER),
		&dwBytesRead, NULL);

	if (!bSuccess || (dwBytesRead != sizeof(BITMAPFILEHEADER))
		|| (bmfh.bfType != *(WORD *) "BM"))
	{
		CloseHandle(hFile);
		return;
	}

	// Allocate memory for the BITMAPINFO structure & read it in

	dwInfoSize = bmfh.bfOffBits - sizeof(BITMAPFILEHEADER);

	pbmi = (BITMAPINFO *)malloc(dwInfoSize);

	bSuccess = ReadFile(hFile, pbmi, dwInfoSize, &dwBytesRead, NULL);

	if (!bSuccess || (dwBytesRead != dwInfoSize))
	{
		free(pbmi);
		CloseHandle(hFile);
		return;
	}

	// Create the DIB Section

	hBitmap = CreateDIBSection(NULL, pbmi, DIB_RGB_COLORS, (void **)&pBits, NULL, 0);

	if (hBitmap == NULL)
	{
		free(pbmi);
		CloseHandle(hFile);
		return;
	}

	// Read in the bitmap bits

	ReadFile(hFile, pBits, bmfh.bfSize - bmfh.bfOffBits, &dwBytesRead, NULL);

	free(pbmi);
	CloseHandle(hFile);

	//return hBitmap ;


	if (hBitmap)
	{
		GetObject(hBitmap, sizeof(BITMAP), &bitmap);

		hdcMem = CreateCompatibleDC(hdc);
		SelectObject(hdcMem, hBitmap);

		BitBlt(hdc, 0, 0, bitmap.bmWidth, bitmap.bmHeight,
			hdcMem, 0, 0, SRCCOPY);

		DeleteDC(hdcMem);
	}

	if (hBitmap)
	{
		DeleteObject(hBitmap);
		hBitmap = NULL;
	}


}

/*void shwoImage()

{

	graphics = new Graphics(hdc);

	image = new Image(L"C:\\map.png", 0, 0); //��ʾc�̵�map.pngͼƬ



	delete image;

	delete graphics;

}/

/*
   �滭PNGͼ��
*/
/*bool DrawImagePng(HDC DC, INT nXPos, INT nYPos)
{
	//�����ж�
	assert(m_pImage != NULL);
	if (m_pImage == NULL) return false;

	//������Ļ
	assert(DC != NULL);
	Graphics graphics(DC);

	//��ȡ����
	INT nImageWidth = m_pImage->GetWidth();
	INT nImageHeight = m_pImage->GetHeight();

	//����λ��
	RectF rcDrawRect;
	rcDrawRect.X = (REAL)nXPos;
	rcDrawRect.Y = (REAL)nYPos;
	rcDrawRect.Width = (REAL)nImageWidth;
	rcDrawRect.Height = (REAL)nImageHeight;

	//�滭ͼ��
	graphics.DrawImage(m_pImage, rcDrawRect, 0, 0, (REAL)nImageWidth, (REAL)nImageHeight, UnitPixel);

	return true;
}*/

// ����KM_ACTIONֵ����������Ϊ
void EngineTest::GameKeyAction(int ActionType){}
// ����KM_ACTIONֵ���������Ϊ
void EngineTest::GameMouseAction(int x, int y, int ActionType){}
